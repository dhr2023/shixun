package com.team.springboot.pojo;

public class ShoppingCar {
    private int s_Id;
    private String u_Account;
    private int p_Id;

    public int getS_Id() {
        return s_Id;
    }

    public void setS_Id(int s_Id) {
        this.s_Id = s_Id;
    }

    public String getU_Account() {
        return u_Account;
    }

    public void setU_Account(String u_Account) {
        this.u_Account = u_Account;
    }

    public int getP_Id() {
        return p_Id;
    }

    public void setP_Id(int p_Id) {
        this.p_Id = p_Id;
    }
}
