package com.team.springboot.utils;

public class utils {
}
