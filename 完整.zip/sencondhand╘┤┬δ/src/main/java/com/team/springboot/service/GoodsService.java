package com.team.springboot.service;

import com.team.springboot.pojo.Product;

public interface GoodsService {
    Product selectProduct(int p_Id);
}
